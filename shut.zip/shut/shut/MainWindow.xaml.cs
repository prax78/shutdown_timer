﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace shut
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public System.Windows.Threading.DispatcherTimer tmr = new System.Windows.Threading.DispatcherTimer();
        [DllImport("advapi32.dll", SetLastError = true)]
        static extern UInt32 InitiateShutdown(
    string lpMachineName,
    string lpMessage,
    UInt32 dwGracePeriod,
    UInt32 dwShutdownFlags,
    UInt32 dwReason);
        public MainWindow()
        {


            InitializeComponent();
            int hr = 0;
            int sec = 0;


            for (hr = 0; hr <= 23; hr++)
            {
                Hour.Items.Add(hr);

            }

            for (sec = 0; sec <= 59; sec++)
            {
                Minutes.Items.Add(sec);

            }
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            if ((Hour.SelectedItem != null) && (Minutes.SelectedItem != null))
            {
                button.IsEnabled = false;

                tmr.Interval = TimeSpan.FromSeconds(1);
                tmr.Tick += shutdown;
                tmr.Start();
                label1.Content = "Timer has been set,minimize window";

            }
            else
            {
                MessageBox.Show("select hour and minutes please");
            }

        }

        void shutdown(object sender, EventArgs e)
        {

            if ((Hour.SelectedValue.ToString() == DateTime.Now.Hour.ToString()) && (Minutes.SelectedValue.ToString() == DateTime.Now.Minute.ToString()))
            {
                powerdown();
            }
        }
        void powerdown()
        {
            InitiateShutdown("localhost", "shuttingdown", 10, 0, 0);

            tmr.Stop();
        }
    }
}
